<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4 text-center"><?php echo $title; ?></h1>
    <p class="lead text-center"><?php echo $subtitle; ?></p>
  </div>
</div>