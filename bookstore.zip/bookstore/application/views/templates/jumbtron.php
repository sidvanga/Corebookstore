<div class="jumbotron jumbotron-fluid main-jumbotron">
  <div class="container">
    <h1 class="display-4">BookStore</h1>
    <p class="lead">One stop shop online to get your favourite books.</p>
  </div>
</div>