<div class="container" style="width:20rem">
    <a  href="<?php echo base_url("create_category");?>" 
        class="btn btn-outline-primary btn-lg btn-block ">Create New Category</a>
    <a  href="<?php echo base_url("add_book");?>" class="btn btn-outline-primary btn-lg btn-block ">Add New Book</a>
</div>