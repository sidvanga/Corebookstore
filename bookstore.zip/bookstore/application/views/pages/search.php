<div class="container mt-5 mb-5 text-center">
    <h5><?php echo '"'.$search_details.'"'?></h5>
</div>
